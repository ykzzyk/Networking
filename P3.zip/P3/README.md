# README

To run the smtp_client.py: python smtp_client.py

To run the smtp_client_img.py: python smtp_client_img.py